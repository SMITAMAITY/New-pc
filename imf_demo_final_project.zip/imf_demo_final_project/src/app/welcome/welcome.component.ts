import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {AuthenticationService, UserDetails} from '../authentication.service'


@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

 
  details:UserDetails

   
  constructor(public auth: AuthenticationService,private router : Router){}

  ngOnInit() {

    
      if(localStorage.getItem("usertoken") == null){
        alert('Please login First')
     
    }
 
      this.auth.profile().subscribe(
          user => {
              this.details =user
          },
          err => {
              console.error(err)
          }

      )

      this.auth.profile().subscribe(
        user => {
            this.details =user
            if(user.role == 'Approver'){
              setTimeout(() => {
                this.router.navigate(['/applicationOne']);
                },4000);
            }


            if(user.role == 'User')
            {
                setTimeout(() => {
                this.router.navigate(['/applications']);
                },4000);
              }
        
              })
            }
          }



 
 
