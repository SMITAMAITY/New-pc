import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-iframe',
  templateUrl: './iframe.component.html',
  styleUrls: ['./iframe.component.css']
})
export class IframeComponent {
  constructor(public auth: AuthenticationService){}

 public ingestion: string = `https://mosaic.ga.lti-mosaic.com/decisions/#/`;
 public wrangler: string = `https://mosaic.ga.lti-mosaic.com/lensui/#/lens`;
 public reporting: string = `https://itime.lntinfotech.com/Forms/HomeNew.html`;
 public workflow: string = `https://lntdemo.appiancloud.com/suite?signin=native`;

 public metadata: string = `https://mosaic.ga.lti-mosaic.com/mosaiccatalog/discover/#/`;

 public marketplace: string = `https://lntdemo.appiancloud.com/suite/design`;
 
 public pintrest: string = `https://www.imf.org/en/Data`;


}
