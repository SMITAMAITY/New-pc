import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ingestion-four',
  templateUrl: './ingestion-four.component.html',
  styleUrls: ['./ingestion-four.component.css']
})
export class IngestionFourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
