import { Component, OnInit } from '@angular/core';
import {AuthenticationService, UserDetails} from '../authentication.service'
import { Router } from '@angular/router';
import { bufferToggle } from 'rxjs/operators';
import { SubmitService } from '../submit.service';



import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

import { Subject } from 'rxjs';

@Component({
  selector: 'app-applications',
  templateUrl: './applications.component.html',
  styleUrls: ['./applications.component.css']
})
export class ApplicationsComponent implements OnInit {

  details: UserDetails;


  ingestion=false;
  wrangler=false;
  reporting=false;
  workflow=false;
  metadata=false;
  marketplace=false;

  public show:boolean = false;
  public buttonName:any = 'Show Notification';



  taskData: any[] = [];

  public apidata;
  httpOption = {
    headers: new HttpHeaders({
      'Authorization': 'Basic ' + btoa('imf.demo:Appian123'),
      'Content-Type': 'application/json'
    })
  }

 

  //apiurl = `https://lntdemo.appiancloud.com/suite/webapi/getAllTasks?approver=imf.demo`;
  apiurl = `https://lntdemo.appiancloud.com/suite/webapi/IMFiData`;


  constructor(private submitService: SubmitService, public auth: AuthenticationService,private router : Router, private httpClient: HttpClient){}


  ngOnInit(): void {
    //alert('Application Component');
    console.log(this.submitService.getTaskData());

    if(localStorage.getItem("usertoken") == null){
       alert('Please login First')
      this.router.navigateByUrl('')
  }
    this.auth.profile().subscribe(
      user => {
          this.details =user
          // if( user.Name == 'John David')
          // {
          //   this.ingestion=true;
          // this.wrangler=true;
          // this.workflow=true;
          // this.marketplace=true;
          // }
          // else{
          if(user.role == 'User')
          {
            this.ingestion=true;
          this.wrangler=true;
          this.reporting=true;
          this.workflow=true;
          this.metadata=true;
          this.marketplace=true;
            
            
          }

     

        else if(user.role == 'Approver')
        {
          this.ingestion=true;
          this.wrangler=true;
          this.reporting=true;
          this.workflow=true;
          this.metadata=true;
          this.marketplace=true;
        }
      },
      err => {
          console.error(err)
      }


  )     






  
}


toggle() {
  this.show = !this.show;

  // CHANGE THE NAME OF THE BUTTON.
  if(this.show)  {
    this.buttonName = "Hide Notification";
    console.log(this.submitService.getTaskData());


    }
  else
    this.buttonName = "Show Notification";
    

}



}
  


