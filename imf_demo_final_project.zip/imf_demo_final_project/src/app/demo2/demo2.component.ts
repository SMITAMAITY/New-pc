import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { SubmitService } from '../submit.service';

@Component({
  selector: 'app-demo2',
  templateUrl: './demo2.component.html',
  styleUrls: ['./demo2.component.css']
})
export class Demo2Component  {

  public apidata;
  httpOption = {
    headers: new HttpHeaders({
      'Authorization': 'Basic ' + btoa('imf.demo:Appian123'),
      'Content-Type': 'application/json'
    })
  }


  apiurl=`https://lntdemo.appiancloud.com/suite/webapi/TaskId?procId=`;
  constructor( private httpClient : HttpClient , private router : Router, public sub : SubmitService) { }


  

  approve():void{
  //   console.log(this.httpOption);
    

    
  //   this.httpClient.get(this.apiurl, this.httpOption).subscribe(response => {
  //     this.apidata = response;
  //     console.log(this.apidata);
  //    // alert('Approved')
  //     this.router.navigateByUrl('applicationOne')
  // });
  
    this.sub.onApprove();
    console.log('Success');
    
  
  }
  
  reject():void{
    console.log(this.httpOption);
    

    
  //   this.httpClient.get(this.apiurl, this.httpOption).subscribe(response => {
  //     this.apidata = response;
  //     console.log(this.apidata);
  //    // alert('Reject')
  //     this.router.navigateByUrl('applicationOne')
  // });
  this.sub.onReject();
  console.log('Reject');

}


}
