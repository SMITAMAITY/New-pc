import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { SubmitService } from '../submit.service';

@Component({
  selector: 'app-submit',
  templateUrl: './submit.component.html',
  styleUrls: ['./submit.component.css']
})
export class SubmitComponent implements OnInit {
 // public apidata;
  

 
  /* httpOption = {
    headers: new HttpHeaders().set('Content-Type', 'application/json').append('Authorization', 'Basic ' + btoa('imf.demo:Appian123'))
  } */

  //apiurl = `https://lntdemo.appiancloud.com/suite/webapi/IMFiData`;
  constructor(private httpClient: HttpClient, private router: Router, public sub: SubmitService ) { }


  //apiurl1 = `https://lntdemo.appiancloud.com/suite/webapi/TaskId?procId=`;
  ngOnInit() {

  }

  // onSubmit(): void {
  //   console.log(this.httpOption);
  //   this.httpClient.post(this.apiurl, JSON.stringify({ "approver": "imf.demo" }), this.httpOption).subscribe(
  //     data => {
  //       console.log(data);
  //       this.httpClient.get(this.apiurl1 + '' + data['ProcId'], this.httpOption).subscribe(response => {
  //         this.apidata = response;
  //         console.log(this.apidata);
  //         // alert('Reject')
  //         // this.router.navigateByUrl('applications')
  //       });
  //     }
  //   )
  //   //   this.httpClient.get(this.apiurl).subscribe(response => {
    //     this.apidata = response;
    //     // console.log(this.apidata);
    //     alert(this.apidata);
    // });


    /* this.httpClient.get(this.apiurl1, this.httpOption).subscribe(response => {
      this.apidata = response;
      console.log(this.apidata);
      // alert('Reject')
      // this.router.navigateByUrl('applications')
    }); */

    submit():void{
      this.sub.onSubmit();
      console.log('Success');
      
    }
  }




