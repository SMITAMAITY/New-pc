import { Component, OnInit } from '@angular/core';
import { AuthenticationService, UserDetails } from '../authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-metadata',
  templateUrl: './metadata.component.html',
  styleUrls: ['./metadata.component.css']
})
export class MetadataComponent {

  details:UserDetails

   
    constructor(public auth: AuthenticationService,private router : Router){}
  
   

    ngOnInit() {


     
        this.auth.profile().subscribe(
          user => {
              this.details =user
          },
          err => {
              console.error(err)
          }

      )
            }
          
          

        back(): void {
  
          this.auth.profile().subscribe(
            user => {
                this.details =user
              
      
                if(user.role == 'Approver')
                {
                    
                    this.router.navigate(['/applicationOne']);
              
                  }
            
                if(user.role == 'User')
                {
                    
                    this.router.navigate(['/applications']);
              
                  }
            
                  },
                      err => {
                          console.error(err)
                       })
                }
  
              }
              
  
  
          
   

 