import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IngestionSixComponent } from './ingestion-six.component';

describe('IngestionSixComponent', () => {
  let component: IngestionSixComponent;
  let fixture: ComponentFixture<IngestionSixComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IngestionSixComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IngestionSixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
