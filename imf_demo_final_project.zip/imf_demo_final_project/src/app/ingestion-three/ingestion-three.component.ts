import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ingestion-three',
  templateUrl: './ingestion-three.component.html',
  styleUrls: ['./ingestion-three.component.css']
})
export class IngestionThreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
