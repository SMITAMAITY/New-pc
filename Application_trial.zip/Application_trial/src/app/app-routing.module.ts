import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { FormOneComponent } from './form-one/form-one.component';
import { FormTwoComponent } from './form-two/form-two.component';
import { ThreeComponent } from './three/three.component';





const routes: Routes = [
  { path : '', component : FormOneComponent },
  { path : 'two', component : FormTwoComponent },
  { path : 'three', component : ThreeComponent }
]



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
