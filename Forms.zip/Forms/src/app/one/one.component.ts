import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Validators } from '@angular/forms';


@Component({
  selector: 'app-one',
  templateUrl: './one.component.html',
  styleUrls: ['./one.component.css']
})
export class OneComponent implements OnInit {
data:any;

  entry = new FormGroup({
    rrid: new FormControl(null, Validators.required),
    title:new FormControl(null, Validators.required),
    overview:new FormControl(null, Validators.required),
    duties:new FormControl(null, Validators.required),
    education:new FormControl(null, Validators.required),
    experience:new FormControl(null, Validators.required),
    skills:new FormControl(null, Validators.required),
    fileUplaod: new FormControl(null, [Validators.required])
    // abilities:new FormControl(null, Validators.required)
  });


  constructor(private router : Router) { }

  ngOnInit(): void {
  }

  submit(){
    this.data=JSON.stringify(this.entry.value);
    this.router.navigateByUrl('two');
  }
}
