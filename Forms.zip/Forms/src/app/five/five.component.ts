import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-five',
  templateUrl: './five.component.html',
  styleUrls: ['./five.component.css']
})
export class FiveComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  approve(){
    this.router.navigateByUrl('six');
  }

  reject(){
    this.router.navigateByUrl('');
  }

}
