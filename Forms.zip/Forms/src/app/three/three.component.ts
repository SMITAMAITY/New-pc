import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-three',
  templateUrl: './three.component.html',
  styleUrls: ['./three.component.css']
})
export class ThreeComponent  {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }


  approve(){
    this.router.navigateByUrl('four');
  }

  reject(){
    this.router.navigateByUrl('');
  }
}
