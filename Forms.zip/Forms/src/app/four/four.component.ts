import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-four',
  templateUrl: './four.component.html',
  styleUrls: ['./four.component.css']
})
export class FourComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  approve(){
    this.router.navigateByUrl('five');
  }

  reject(){
    this.router.navigateByUrl('');
  }
}
