import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-six',
  templateUrl: './six.component.html',
  styleUrls: ['./six.component.css']
})
export class SixComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  approve(){
    this.router.navigateByUrl('five');
  }

  reject(){
    this.router.navigateByUrl('');
  }

}
