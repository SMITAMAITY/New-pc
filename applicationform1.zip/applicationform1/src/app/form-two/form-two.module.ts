import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormTwoRoutingModule } from './form-two-routing.module';
import { FormTwoComponent } from './form-two.component';


@NgModule({
  declarations: [FormTwoComponent],
  imports: [
    CommonModule,
    FormTwoRoutingModule
  ]
})
export class FormTwoModule { }
