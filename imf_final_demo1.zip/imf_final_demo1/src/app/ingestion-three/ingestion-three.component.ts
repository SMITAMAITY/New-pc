import { Component, OnInit } from '@angular/core';
import { AuthenticationService, UserDetails } from '../authentication.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-ingestion-three',
  templateUrl: './ingestion-three.component.html',
  styleUrls: ['./ingestion-three.component.css']
})
export class IngestionThreeComponent implements OnInit {
  details:UserDetails

  constructor(public auth: AuthenticationService,private router : Router) { }

  ngOnInit(): void {

    this.auth.profile().subscribe(
      user => {
          this.details =user
      })

}
}
