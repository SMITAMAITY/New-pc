import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectgraphComponent } from './rejectgraph.component';

describe('RejectgraphComponent', () => {
  let component: RejectgraphComponent;
  let fixture: ComponentFixture<RejectgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RejectgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RejectgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
