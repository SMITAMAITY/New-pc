import { Injectable } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { AuthenticationService, UserDetails } from './authentication.service';



@Injectable({
  providedIn: 'root'
})
export class SubmitService {

  details:UserDetails;
  taskData: any[] = [];

  public apidata;
  httpOption = {
    headers: new HttpHeaders({
      'Authorization': 'Basic ' + btoa('imf.demo:Appian123'),
      'Content-Type': 'application/json'
    })
  }

  /* httpOption = {
    headers: new HttpHeaders().set('Content-Type', 'application/json').append('Authorization', 'Basic ' + btoa('imf.demo:Appian123'))
  } */

  apiurl = `https://lntdemo.appiancloud.com/suite/webapi/IMFiData`;
  
  constructor(private httpClient: HttpClient, private router: Router,public auth: AuthenticationService ) { }


  apiurl1 = `https://lntdemo.appiancloud.com/suite/webapi/TaskId?procId=`;

  apiurl2 = `https://lntdemo.appiancloud.com/suite/webapi/iDataCompleteTask`;

  

   



  getTaskData() {
    return this.taskData;
  }

  onSubmit(): void {
    console.log(this.httpOption);


   
    
    this.auth.profile().subscribe(
      user => {
          this.details =user


          //localStorage.setItem("name",this.details.Name)

          this.httpClient.post(this.apiurl, JSON.stringify({"requestor":this.details.Name,"approver":"Dadan.Sikandar"}), this.httpOption).subscribe(
            data => {
              console.log(data);
              this.httpClient.get(this.apiurl1 + '' + data['ProcId'], this.httpOption).subscribe(response => {
                this.apidata = response;
                console.log(this.apidata);
                this.taskData.push(this.apidata);
                console.log(this.taskData);
                sessionStorage.setItem('dummyData', JSON.stringify(this.taskData));
                // alert('Reject')
               this.router.navigateByUrl('applications')
              });
            }
          )
      }
   
  )

    
  }


onApprove(): void{
  console.log(this.httpOption);
  let taskIds = JSON.parse(localStorage.getItem('taskId'));
  this.httpClient.post(this.apiurl2, JSON.stringify({"taskId":taskIds[taskIds.length-1]['taskId'],"action":"Approve"}), this.httpOption).subscribe(
    data => {
      console.log(data);
      // this.httpClient.get(this.apiurl1 + '' + data['ProcId'], this.httpOption).subscribe(response => {
      //   this.apidata = response;
      //   console.log(this.apidata);
      //   this.taskData.push(this.apidata);
      //   console.log(this.taskData);
      //   localStorage.setItem('dummyData', this.taskData.toString());
      //   // alert('Reject')
        this.router.navigateByUrl('applicationOne')
        //sessionStorage.removeItem('dummyData');
      });
    }
  

    onReject(): void{
      console.log(this.httpOption);
      let taskIds = JSON.parse(localStorage.getItem('taskId'));
      this.httpClient.post(this.apiurl2, JSON.stringify({"taskId":taskIds[taskIds.length-1]['taskId'],"action":"Reject"}), this.httpOption).subscribe(
        data => {
          console.log(data);
          // this.httpClient.get(this.apiurl1 + '' + data['ProcId'], this.httpOption).subscribe(response => {
          //   this.apidata = response;
          //   console.log(this.apidata);
          //   this.taskData.push(this.apidata);
          //   console.log(this.taskData);
          //   localStorage.setItem('dummyData', this.taskData.toString());
          //   // alert('Reject')
           this.router.navigateByUrl('applicationOne')
         //  localStorage.removeItem('dummyData');
          });
        }

        

 

        
}


